Description
Stick Offline is a 2D, 2 player stick figure fighting game.

Help
To access the game's help press start on any screen.

Credits
Stick Offline is an unofficial fan made game based off Stick Online. Graphics and game ideas are from Stick Online. Credit to Meiun and the Stick Online team. To learn more about Stick Online go to www.stick-online.com

Programing / Design: ARTgames
Design / Testing: LoneProvo, Turkey
Sound effects are made with: http://www.drpetter.se/project_sfxr.html

Software is provided as is, no warranty. Not responsible for any effects of this software on users' systems.
